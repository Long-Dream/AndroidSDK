import java.util.Map;
import java.util.Set;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;

public class Output {
	public void printMap(String a) throws IOException {
		FileOutputStream fs = new FileOutputStream(new File(a));
		PrintStream p = new PrintStream(fs);
		Map<String, Set<String>> testmap = IntentAnalysis.getAllActivity();
		p.println("=== result ===");
		for(Map.Entry<String, Set<String>> entry:testmap.entrySet()) {
			p.println(entry.getKey());
			for (String s : entry.getValue()) {
				p.println("-> " + s);
			}
			p.println();
		}
		p.close();
	}
	public static void print(String a, String b, int c) throws FileNotFoundException {
		if (c == 0) {
			FileOutputStream fs = new FileOutputStream(new File(a));
			PrintStream p = new PrintStream(fs);
			p.println(b);
			p.close();
		} else {
			FileOutputStream fs = new FileOutputStream(new File(a), true);
			PrintStream p = new PrintStream(fs);
			p.print(b + "\n");
			p.close();
		}
	}
}