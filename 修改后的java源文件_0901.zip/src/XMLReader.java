import java.io.*;
import java.util.Stack;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
public class XMLReader {
	public static Stack<String> actionFinder(String argu, String outpath) {
		Stack<String> intents = new Stack<String>();
		Element element = null;
		File f = new File(outpath + "/AndroidManifest.xml");
		DocumentBuilder db = null;
		DocumentBuilderFactory dbf = null;
		try {
			dbf = DocumentBuilderFactory.newInstance();
			db = dbf.newDocumentBuilder();
			Document dt = db.parse(f);
			element = dt.getDocumentElement();
			//System.out.println(element.getNodeName());
			NodeList applicationNode = element.getChildNodes();
			for (int i = 0; i < applicationNode.getLength(); i++) {
				Node application = applicationNode.item(i);
				if ("application".equals(application.getNodeName())) {
					NodeList activityNode = application.getChildNodes();
					for (int j = 0; j < activityNode.getLength(); j++) {
						Node activity = activityNode.item(j);
						if ("activity".equals(activity.getNodeName())) {
							//System.out.println("com.example.intenttest" + activity.getAttributes().getNamedItem("android:name").getNodeValue());
							
							NodeList intentfilterNode = activity.getChildNodes();
							for (int k = 0; k < intentfilterNode.getLength(); k++) {
								Node intentfilter = intentfilterNode.item(k);
								if ("intent-filter".equals(intentfilter.getNodeName())) {
									NodeList actionNode = intentfilter.getChildNodes();
									for (int l = 0; l < actionNode.getLength(); l++) {
										Node action = actionNode.item(l);
										if("action".equals(action.getNodeName())) {
											//System.out.println("	" + action.getAttributes().getNamedItem("android:name").getNodeValue());
											if (argu.equals("\"" + action.getAttributes().getNamedItem("android:name").getNodeValue() + "\"")) {
												if (activity.getAttributes().getNamedItem("android:name").getNodeValue().contains(element.getAttributes().getNamedItem("package").getNodeValue())) {
													intents.add(activity.getAttributes().getNamedItem("android:name").getNodeValue());
												} else if (activity.getAttributes().getNamedItem("android:name").getNodeValue().substring(0, 3).equals("com")) {
													intents.add(activity.getAttributes().getNamedItem("android:name").getNodeValue());
												} else if (activity.getAttributes().getNamedItem("android:name").getNodeValue().substring(0, 1).equals(".")) {
													intents.add(element.getAttributes().getNamedItem("package").getNodeValue() + activity.getAttributes().getNamedItem("android:name").getNodeValue());
												} else {
													intents.add(element.getAttributes().getNamedItem("package").getNodeValue() + "." + activity.getAttributes().getNamedItem("android:name").getNodeValue());
												}
												
											}
										}
									}
								}
							}
						}
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return intents;
	}
	
	public void actionOutput(String a, String outpath) throws Exception {
		FileOutputStream fs = new FileOutputStream(new File(a), true);
		PrintStream pr = new PrintStream(fs);
		pr.println("=== Activities and Actions ===");
		
		Element element = null;
		File f = new File(outpath + "/AndroidManifest.xml");
		DocumentBuilder db = null;
		DocumentBuilderFactory dbf = null;
		try {
			dbf = DocumentBuilderFactory.newInstance();
			db = dbf.newDocumentBuilder();
			Document dt = db.parse(f);
			element = dt.getDocumentElement();
			//System.out.println(element.getNodeName());
			NodeList applicationNode = element.getChildNodes();
			for (int i = 0; i < applicationNode.getLength(); i++) {
				Node application = applicationNode.item(i);
				if ("application".equals(application.getNodeName())) {
					NodeList activityNode = application.getChildNodes();
					for (int j = 0; j < activityNode.getLength(); j++) {
						Node activity = activityNode.item(j);
						if ("activity".equals(activity.getNodeName())) {
							if (activity.getAttributes().getNamedItem("android:name").getNodeValue().contains(element.getAttributes().getNamedItem("package").getNodeValue())) {
								pr.println(activity.getAttributes().getNamedItem("android:name").getNodeValue());
							} else if (activity.getAttributes().getNamedItem("android:name").getNodeValue().substring(0, 3).equals("com")) {
								pr.println(activity.getAttributes().getNamedItem("android:name").getNodeValue());
							} else if (activity.getAttributes().getNamedItem("android:name").getNodeValue().substring(0, 1).equals(".")) {
								pr.println(element.getAttributes().getNamedItem("package").getNodeValue() + activity.getAttributes().getNamedItem("android:name").getNodeValue());
							} else {
								pr.println(element.getAttributes().getNamedItem("package").getNodeValue() + "." + activity.getAttributes().getNamedItem("android:name").getNodeValue());
							}
							
							NodeList intentfilterNode = activity.getChildNodes();
							for (int k = 0; k < intentfilterNode.getLength(); k++) {
								Node intentfilter = intentfilterNode.item(k);
								if ("intent-filter".equals(intentfilter.getNodeName())) {
									NodeList actionNode = intentfilter.getChildNodes();
									for (int l = 0; l < actionNode.getLength(); l++) {
										Node action = actionNode.item(l);
										if("action".equals(action.getNodeName())) {
											pr.println("   " + action.getAttributes().getNamedItem("android:name").getNodeValue());
										}
									}
								}
							}
							
						}
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		pr.close();
	}
	
	public static boolean activityFinder(String argu, String outpath) {
		Element element = null;
		File f = new File(outpath + "/AndroidManifest.xml");
		DocumentBuilder db = null;
		DocumentBuilderFactory dbf = null;
		try {
			dbf = DocumentBuilderFactory.newInstance();
			db = dbf.newDocumentBuilder();
			Document dt = db.parse(f);
			element = dt.getDocumentElement();
			//System.out.println(element.getNodeName());
			NodeList applicationNode = element.getChildNodes();
			for (int i = 0; i < applicationNode.getLength(); i++) {
				Node application = applicationNode.item(i);
				if ("application".equals(application.getNodeName())) {
					NodeList activityNode = application.getChildNodes();
					for (int j = 0; j < activityNode.getLength(); j++) {
						Node activity = activityNode.item(j);
						if ("activity".equals(activity.getNodeName())) {
							if (argu.equals(activity.getAttributes().getNamedItem("android:name").getNodeValue())) {
								return true;
							} else if (argu.equals(element.getAttributes().getNamedItem("package").getNodeValue() 
									+ "." + activity.getAttributes().getNamedItem("android:name").getNodeValue())) {
								return true;
							} else if (argu.equals(element.getAttributes().getNamedItem("package").getNodeValue() 
									+ activity.getAttributes().getNamedItem("android:name").getNodeValue())) {
								return true;
							}
						}
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;
	}
}