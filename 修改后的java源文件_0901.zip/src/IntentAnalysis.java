import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Stack;

import soot.Unit;
import soot.Value;
import soot.jimple.InvokeExpr;
import soot.jimple.InvokeStmt;

public class IntentAnalysis {

	private static String invokeActivity = null;
	private static String targetActivity = null;
	
	private static Map<String, Set<String>> activityMap = new HashMap<String, Set<String>>();
	
	public static void activityAnalysis(String invokeStr, Stack<Unit> unitStack, String outpath) throws Exception{
		if (unitStack.size() == 0) {
			return;
		}
		int beginIndex = invokeStr.indexOf("<") + 1;
		int endIndex = invokeStr.indexOf(":");
		invokeActivity = invokeStr.substring(beginIndex, endIndex);
		if (!XMLReader.activityFinder(invokeActivity, outpath)) {
			return;
		}
		if (!activityMap.containsKey(invokeActivity)) {
			Set<String> set = new HashSet<>();
			activityMap.put(invokeActivity, set);
		}
		Unit unit = null;
		while(!unitStack.empty()){
			//targetActivity = null;
			unit = unitStack.pop();
			InvokeExpr invokeExpr = ((InvokeStmt)unit).getInvokeExpr();
			String methodName = invokeExpr.getMethod().getName();			
			if (methodName.equals("<init>")) {
				List<Value> args = invokeExpr.getArgs();
				if (args.size() == 1) {
					String arg = invokeExpr.getArg(0).toString();
					new XMLReader();
					Stack<String> act = XMLReader.actionFinder(arg, outpath);
					while(!act.isEmpty()) {
						targetActivity = act.pop();
						activityMap.get(invokeActivity).add(targetActivity);
					}
				} else if (args.size() == 2) {
					if (args.get(1).getType().toString().equals("java.lang.Class")) {
						targetActivity = args.get(1).toString();
						if (targetActivity != null && targetActivity.contains("\"")) {
							targetActivity = targetActivity.split("\"")[1].replace('/', '.');
							activityMap.get(invokeActivity).add(targetActivity);
						}
					}
				}

			} else if (methodName.equals("setClass")) {
				targetActivity = invokeExpr.getArg(1).toString();
				if (targetActivity != null && targetActivity.contains("\"")){
					targetActivity = targetActivity.split("\"")[1].replace('/', '.');
					activityMap.get(invokeActivity).add(targetActivity);
				}	
			} else if (methodName.equals("setClassName")) {
				targetActivity = invokeExpr.getArg(1).toString();
				if (targetActivity.substring(0, 2).equals("$r")) {
					continue; // r output bug fix!
				}
				targetActivity = (targetActivity.substring(1, targetActivity.length() - 1)).replace("/", ".");
				activityMap.get(invokeActivity).add(targetActivity);
			} else if (methodName.equals("setAction")) {
				String args = invokeExpr.getArg(0).toString();
				new XMLReader();
				Stack<String> act = XMLReader.actionFinder(args, outpath);
				while(!act.isEmpty()) {
					targetActivity = act.pop();
					activityMap.get(invokeActivity).add(targetActivity);
				}
			} else if (invokeExpr.getMethod().getDeclaringClass().getName().equals("android.content.ComponentName")) {
				if (methodName.equals("<init>")) {
					targetActivity = invokeExpr.getArg(1).toString();
					if (targetActivity.contains("\"") && !targetActivity.equals("\"\"")) {
						targetActivity = targetActivity.split("\"")[1];
						activityMap.get(invokeActivity).add(targetActivity);
					}
				}
			}
		}
		unitStack.clear();
		//activityMap.get(invokeActivity).add(targetActivity);
	}

	public static Map<String, Set<String>> getAllActivity(){
		return activityMap;
	}
	
}
